<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bandung Visit Tour Package - Wisata Bandung</title>
    <link rel="stylesheet" href="paket.css">
   
    </head>
    <?php include 'navbar.php'; ?>
<body>

 

    <!-- Package Section -->
    <section class="packages" id="packages">
        <div class="container">
            <div class="section-title">
                <h2>Pemesanan Wisata Bandung</h2>
                <p>Pilih paket wisata sesuai dengan kebutuhan dan budget Anda. Semua paket sudah termasuk transportasi, penginapan, dan pemandu wisata.</p>
            </div>
            
            <div class="package-filters">
                <button class="filter-btn active" data-filter="all">Semua Paket</button>
                <button class="filter-btn" data-filter="budget">Budget</button>
                <button class="filter-btn" data-filter="family">Keluarga</button>
                <button class="filter-btn" data-filter="honeymoon">Honeymoon</button>
                <button class="filter-btn" data-filter="custom">Custom</button>
            </div>
            
            
            <div class="package-grid">
                <!-- Package 1 -->
                <div class="package-card" data-category="budget">
                    <div class="package-img">
                        <img src="download.jpg" alt="Paket Wisata Bandung 3 Hari 2 Malam">
                    </div>
                    <div class="package-content">
                        <h3>Bandung 3 Hari 2 Malam</h3>
                        <div class="package-meta">
                            <span><i class="far fa-clock"></i> 3 Hari 2 Malam</span>
                            <span><i class="fas fa-users"></i> 2-4 Orang</span>
                        </div>
                        <div class="package-price">Rp 1.250.000 / Orang</div>
                        <ul class="package-features">
                            <li><i class="fas fa-check"></i> Hotel Bintang 3</li>
                            <li><i class="fas fa-check"></i> Transportasi AC</li>
                            <li><i class="fas fa-check"></i> Pemandu Wisata</li>
                            <li><i class="fas fa-check"></i> Tiket Masuk Destinasi</li>
                            <li><i class="fas fa-check"></i> Makan 5x</li>
                        </ul>
                       <a href="#" class="btn btn-primary">Pesan Sekarang</a>
                    </div>
                </div>
                
                <!-- Package 2 -->
                <div class="package-card" data-category="family">
                    <div class="package-img">
                        <img src="Bandung_city_centre_-_evening_cropped.jpg" alt="Paket Wisata Keluarga Bandung">
                    </div>
                    <div class="package-content">
                        <h3>Paket Keluarga Bandung</h3>
                        <div class="package-meta">
                            <span><i class="far fa-clock"></i> 4 Hari 3 Malam</span>
                            <span><i class="fas fa-users"></i> 4-6 Orang</span>
                        </div>
                        <div class="package-price">Rp 3.500.000 / Keluarga</div>
                        <ul class="package-features">
                            <li><i class="fas fa-check"></i> Hotel Bintang 4</li>
                            <li><i class="fas fa-check"></i> Transportasi AC</li>
                            <li><i class="fas fa-check"></i> Pemandu Wisata</li>
                            <li><i class="fas fa-check"></i> Tiket Masuk Destinasi</li>
                            <li><i class="fas fa-check"></i> Makan 8x</li>
                        </ul>
                       <a href="#" class="btn btn-primary">Pesan Sekarang</a>
                    </div>
                </div>
                
                <!-- Package 3 -->
                <div class="package-card" data-category="honeymoon">
                    <div class="package-img">
                        <img src="https://images.unsplash.com/photo-1566073771259-6a8506099945?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=600&q=80" alt="Paket Honeymoon Bandung">
                    </div>
                    <div class="package-content">
                        <h3>Paket Honeymoon Bandung</h3>
                        <div class="package-meta">
                            <span><i class="far fa-clock"></i> 5 Hari 4 Malam</span>
                            <span><i class="fas fa-users"></i> 2 Orang</span>
                        </div>
                        <div class="package-price">Rp 4.200.000 / Pasangan</div>
                        <ul class="package-features">
                            <li><i class="fas fa-check"></i> Hotel Bintang 4</li>
                            <li><i class="fas fa-check"></i> Transportasi Private</li>
                            <li><i class="fas fa-check"></i> Candle Light Dinner</li>
                            <li><i class="fas fa-check"></i> Spa Couple</li>
                            <li><i class="fas fa-check"></i> Tour Romantis</li>
                        </ul>
                      <a href="#" class="btn btn-primary">Pesan Sekarang</a>
                    </div>
                </div>
                <!-- Package 3 -->
                <div class="package-card" data-category="honeymoon">
                    <div class="package-img">
                        <img src="https://images.unsplash.com/photo-1566073771259-6a8506099945?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=600&q=80" alt="Paket Honeymoon Bandung">
                    </div>
                    <div class="package-content">
                        <h3>Paket Honeymoon Bandung</h3>
                        <div class="package-meta">
                            <span><i class="far fa-clock"></i> 5 Hari 4 Malam</span>
                            <span><i class="fas fa-users"></i> 2 Orang</span>
                        </div>
                        <div class="package-price">Rp 4.200.000 / Pasangan</div>
                        <ul class="package-features">
                            <li><i class="fas fa-check"></i> Hotel Bintang 4</li>
                            <li><i class="fas fa-check"></i> Transportasi Private</li>
                            <li><i class="fas fa-check"></i> Candle Light Dinner</li>
                            <li><i class="fas fa-check"></i> Spa Couple</li>
                            <li><i class="fas fa-check"></i> Tour Romantis</li>
                        </ul>
                      <a href="#" class="btn btn-primary">Pesan Sekarang</a>
                    </div>
                </div>  
            </div>
        </div>
    </section>

       

    


  
    <script src="haha.js"></script>
</body>
</html>