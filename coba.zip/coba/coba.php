<?php
// index.php

// Tentukan bahasa default
$default_lang = 'en';
$lang_dir = 'lang/';
$current_lang = $default_lang;

// Cek dari URL atau Cookie
if (isset($_GET['lang']) && in_array($_GET['lang'], ['en', 'id'])) {
    $current_lang = $_GET['lang'];
    setcookie('user_lang', $current_lang, time() + (86400 * 30), '/'); // Simpan 30 hari
} elseif (isset($_COOKIE['user_lang']) && in_array($_COOKIE['user_lang'], ['en', 'id'])) {
    $current_lang = $_COOKIE['user_lang'];
}

// Muat file terjemahan yang sesuai
$lang_file = $lang_dir . $current_lang . '.php';
if (file_exists($lang_file)) {
    $lang = require $lang_file;
} else {
    $lang = require $lang_dir . $default_lang . '.php';
}

function __($key) {
    global $lang;
    return $lang[$key] ?? $key;
}
?>
<!DOCTYPE html>
<html lang="<?php echo $current_lang; ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo __('page_title'); ?></title>
    <link rel="stylesheet" href="style.css"> 
</head>
<body>
    
    <header>
        <div class="logo">SimpleWeb</div>
        <nav>
            <a href="#"><?php echo __('link_home'); ?></a>
            <a href="#"><?php echo __('link_about'); ?></a>
            <a href="#"><?php echo __('link_contact'); ?></a>
        </nav>
        <div class="lang-switcher">
            <a href="?lang=en" class="<?php echo ($current_lang === 'en') ? 'active' : ''; ?>">EN</a>
            <a href="?lang=id" class="<?php echo ($current_lang === 'id') ? 'active' : ''; ?>">ID</a>
        </div>
    </header>

    <main>
        <h2><?php echo __('main_heading'); ?></h2>
        <p><?php echo __('main_paragraph_1'); ?></p>
        <p><?php echo __('main_paragraph_2'); ?></p>
        <a href="#" class="button"><?php echo __('cta_button'); ?></a>
    </main>

    <footer>
        <p><?php echo __('footer_text'); ?></p>
    </footer>

</body>
</html>