<?php
// lang/id.php
return [
    'page_title'      => 'Contoh Situs Web Kami',
    'link_home'       => 'Beranda',
    'link_about'      => 'Tentang Kami',
    'link_contact'    => 'Kontak',
    'main_heading'    => 'Selamat Datang di Masa Depan Desain Web Sederhana',
    'main_paragraph_1'=> 'Situs ini mendemonstrasikan struktur dasar menggunakan PHP, HTML, dan CSS. Fungsionalitas bahasa bekerja sepenuhnya secara offline dengan memuat file teks yang benar.',
    'main_paragraph_2'=> 'Anda dapat beralih antara Bahasa Inggris dan Bahasa Indonesia menggunakan tombol di header. Kodenya bersih, responsif, dan mudah dipelihara.',
    'cta_button'      => 'Pelajari Lebih Lanjut',
    'footer_text'     => '© 2025 Demo Web Sederhana | Semua Hak Dilindungi.'
];