<?php
// lang/en.php
return [
    'page_title'      => 'Our Sample Website',
    'link_home'       => 'Home',
    'link_about'      => 'About',
    'link_contact'    => 'Contact',
    'main_heading'    => 'Welcome to the Future of Simple Web Design',
    'main_paragraph_1'=> 'This site demonstrates a basic structure using PHP, HTML, and CSS. The language functionality works completely offline by loading the correct text file.',
    'main_paragraph_2'=> 'You can switch between English and Indonesian using the toggle in the header. The code is clean, responsive, and easy to maintain.',
    'cta_button'      => 'Learn More',
    'footer_text'     => '© 2025 Simple Web Demo | All Rights Reserved.'
];